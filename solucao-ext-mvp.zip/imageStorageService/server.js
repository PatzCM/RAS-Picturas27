const express = require("express");
const uploadRoutes = require("./route/upload");
const uploadVideoRoutes = require("./route/uploadVideo");
const downloadRoutes = require("./route/download");
const imageRoutes = require("./route/images");
const deleteRoutes = require("./route/delete");
const copyRoutes = require("./route/copy"); 

const app = express();

app.use("/upload", uploadRoutes);
app.use("/upload-video", uploadVideoRoutes);
app.use("/download", downloadRoutes);
app.use("/image", imageRoutes);
app.use("/delete", deleteRoutes);
app.use("/copy", copyRoutes); 

const PORT = process.env.PORT || 11000;

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
